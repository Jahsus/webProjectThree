package promotest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.lang.Thread;
import java.net.URL;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;


public class Core {

    private static WebDriver driver;
    private static WebDriverWait sWebDriverWait;
    private static String url = "https://ivi.ru/";


    static void setup() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");


        TimeoutThread timeoutThread = new TimeoutThread(3);
        timeoutThread.start();
    }

    static void loadMainPage() {
        TimeoutThread timeoutThread = new TimeoutThread(3);
        timeoutThread.start();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        WebDriver driver = new ChromeDriver(options);
        driver.get(url);
        timeoutThread.interrupt();

        Throwable e = ThreadReturn.get(timeoutThread.getName());
        if (e != null) {
            System.out.println("Timed out: " + e.getMessage());
        } else {
            System.out.println("No timeout");
        }

        System.out.println("page loaded");
    }


    static void slidePromo( int count) throws InterruptedException {
        WebElement arrowNext = driver.findElement(By.cssSelector("div.promo span.control.next"));
        System.out.println(arrowNext.getText());

        for(int i = 0; i < count; i++) {
            arrowNext.click();
            Thread.sleep(500);
        }
    }

    public static void clickWatchLatter() throws InterruptedException {
        WebElement watchLatter = driver.findElement(By.xpath("//li[6]/div/a[3]"));
        watchLatter.click();
        String clickedfilmID = watchLatter.getAttribute("data-object-id");
        Thread.sleep(2000);
        System.out.println(clickedfilmID);

    }

    static void checkWatchLatterButton() throws InterruptedException {
        WebElement watchLatter = driver.findElement(By.xpath("//li[6]/div/a[3]"));
        assertThat(watchLatter.getAttribute("class"),is("huge action-link bright js-favourite-button favorite active"));



    }

    static void checkWatchLatterBlock() throws InterruptedException {
        driver.navigate().refresh();
        Thread.sleep(3000);
        String expectedMovieLink = "https://www.ivi.ru/watch/ne-plach-ya-uhozhu";
        String watchLatterLink = driver.findElement(By.cssSelector("#favourites > li:nth-child(1) > a:nth-child(1)")).getAttribute("href");
        String clickedfilmID = driver.findElement(By.xpath("//li[6]/div/a[3]")).getAttribute("data-object-id");
        assertThat(watchLatterLink, is(expectedMovieLink));
        String watchLatterButtonText = driver.findElement(By.cssSelector("#favourites-title > a:nth-child(1)")).getText();
        System.out.println(watchLatterButtonText);
        String selectedFilmID = driver.findElement(By.cssSelector("#favourites > li:nth-child(1)")).getAttribute("data-id");
        System.out.println(clickedfilmID);
        assertThat(watchLatterButtonText,is("См. позже"));
        assertThat(selectedFilmID,is(clickedfilmID));

    }

static void quit(){
    driver.close();
    System.exit(0);
}


}
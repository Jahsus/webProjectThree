package promotest;

import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.junit.runners.JUnit4;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import org.openqa.selenium.WebDriver;
import java.lang.Thread;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;



public class PromoTest {
@BeforeClass
public static void setUpClass() throws Exception {

Core.setup();
}

@After
public void tearDown() throws Exception{
    Core.quit();
}

@Test
public void main() throws Exception {
    Core.loadMainPage();
    Core.slidePromo(5); // локаток стрелки промо-слайдера и количество переходов по слайдам
    Core.clickWatchLatter();
    Core.checkWatchLatterButton();
    Core.checkWatchLatterBlock();

}






//        ChromeOptions options = new ChromeOptions();
//        options.addArguments("--start-maximized");
//        WebDriver driver = new ChromeDriver(options);
//
//        TimeoutThread timeoutThread = new TimeoutThread(3);
//        timeoutThread.start();





//
//
//        Thread.sleep(500);
//        for(int i = 0; i < 5; i++) {
//            arrowNext.click();
//            Thread.sleep(500);
//        }
//
//        watchLatter.click();
//
//
//
//        String clickedfilmID = watchLatter.getAttribute("data-object-id");
//
//
//        Thread.sleep(2000);
//        System.out.println(clickedfilmID);
//
//
//        // Не нашёл как проверить что звезда стала "красной", поэтому проверяю, что класс кнопки изменился на *active
//        assertThat(watchLatter.getAttribute("class"),is("huge action-link bright js-favourite-button favorite active"));
//
//        driver.navigate().refresh();
//        Thread.sleep(3000);
//
//        //Сравнить ссылки на фильм из блока промо и блока См. позже
//        String expectedMovieLink = "https://www.ivi.ru/watch/ne-plach-ya-uhozhu";
//        String watchLatterLink = driver.findElement(By.cssSelector("#favourites > li:nth-child(1) > a:nth-child(1)")).getAttribute("href");
//        assertThat(watchLatterLink, is(expectedMovieLink));
//
//        //Проверить что появилась ссылка "Смотреть позже" и текс "См.позже"
//
//        String buttonText = driver.findElement(By.cssSelector("#favourites-title > a:nth-child(1)")).getText();
//        System.out.println(buttonText);
//
//        String selectedFilmID = driver.findElement(By.cssSelector("#favourites > li:nth-child(1)")).getAttribute("data-id");
//        System.out.println(clickedfilmID);
//
//        assertThat(buttonText,is("См. позже"));
//        assertThat(selectedFilmID,is(clickedfilmID));
//        driver.close();


    }

